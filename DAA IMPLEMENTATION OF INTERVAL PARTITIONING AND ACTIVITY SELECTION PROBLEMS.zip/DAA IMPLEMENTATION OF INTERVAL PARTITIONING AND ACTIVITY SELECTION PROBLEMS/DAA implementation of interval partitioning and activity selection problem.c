/*
 * Greedy scheduling algorithms in C (reads input from the user)
 * 1. Activity Selection     - maximum number of non-overlapping activities
 * 2. Interval Partitioning  - minimum number of rooms for all intervals
 *
 * Compile: gcc -Wall -o greedy_scheduling_input greedy_scheduling_input.c
 * Run:     ./greedy_scheduling_input
 */
#include <stdio.h>
#include <stdlib.h>

#define MAX 100

typedef struct {
    char name[16];
    int start;
    int finish;
} Interval;

/* qsort comparators */
static int cmp_by_finish(const void *a, const void *b) {
    const Interval *x = a, *y = b;
    if (x->finish != y->finish) return x->finish - y->finish;
    return x->start - y->start;
}

static int cmp_by_start(const void *a, const void *b) {
    const Interval *x = a, *y = b;
    if (x->start != y->start) return x->start - y->start;
    return x->finish - y->finish;
}

/* ---------------------------------------------------------------
 * 1. ACTIVITY SELECTION (greedy: earliest finish time first)
 *    Time: O(n log n)
 * --------------------------------------------------------------- */
int activity_selection(Interval acts[], int n, int selected[]) {
    qsort(acts, n, sizeof(Interval), cmp_by_finish);

    int count = 0;
    int last_finish = -2147483647 - 1;      /* smaller than any start time */

    for (int i = 0; i < n; i++) {
        if (acts[i].start >= last_finish) {
            selected[count++] = i;
            last_finish = acts[i].finish;
        }
    }
    return count;
}

/* ---------------------------------------------------------------
 * 2. INTERVAL PARTITIONING (greedy: earliest start time first)
 *    room_end[r] = finish time of the last interval placed in room r.
 *    Time: O(n * rooms), at most O(n^2)
 * --------------------------------------------------------------- */
int interval_partitioning(Interval acts[], int n, int room[]) {
    qsort(acts, n, sizeof(Interval), cmp_by_start);

    int room_end[MAX];
    int rooms = 0;

    for (int i = 0; i < n; i++) {
        int placed = -1;
        for (int r = 0; r < rooms; r++) {
            if (room_end[r] <= acts[i].start) {
                placed = r;
                break;
            }
        }
        if (placed == -1) placed = rooms++;
        room[i] = placed;
        room_end[placed] = acts[i].finish;
    }
    return rooms;
}

/* ---------------------------------------------------------------
 * Input helpers
 * --------------------------------------------------------------- */
static void clear_line(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) { }
}

/* Reads n and then n lines of "name start finish".
 * Returns n on success, or 0 if the input was invalid / ended early. */
int read_intervals(Interval list[], const char *label) {
    int n;
    printf("Enter the number of %s (1-%d): ", label, MAX);
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid number.\n");
        clear_line();
        return 0;
    }

    printf("Enter each one as:  name start finish\n");
    for (int i = 0; i < n; i++) {
        printf("  #%d: ", i + 1);
        if (scanf("%15s %d %d", list[i].name, &list[i].start, &list[i].finish) != 3) {
            printf("Invalid entry.\n");
            clear_line();
            return 0;
        }
        if (list[i].finish <= list[i].start) {
            printf("Finish time must be greater than start time.\n");
            return 0;
        }
    }
    return n;
}

int main(void) {
    int choice;

    for (;;) {
        printf("\n===== Greedy Scheduling =====\n");
        printf("1. Activity Selection\n");
        printf("2. Interval Partitioning\n");
        printf("3. Exit\n");
        printf("Choose an option: ");

        if (scanf("%d", &choice) != 1) break;      /* EOF or non-number */

        if (choice == 1) {
            Interval acts[MAX];
            int selected[MAX];
            int n = read_intervals(acts, "activities");
            if (n == 0) continue;

            int count = activity_selection(acts, n, selected);
            printf("\nMaximum number of activities: %d\n", count);
            for (int i = 0; i < count; i++) {
                Interval *a = &acts[selected[i]];
                printf("  %s: (%d, %d)\n", a->name, a->start, a->finish);
            }
        } else if (choice == 2) {
            Interval lectures[MAX];
            int room[MAX];
            int n = read_intervals(lectures, "intervals");
            if (n == 0) continue;

            int rooms = interval_partitioning(lectures, n, room);
            printf("\nMinimum rooms needed: %d\n", rooms);
            for (int r = 0; r < rooms; r++) {
                printf("  Room %d:", r + 1);
                for (int i = 0; i < n; i++) {
                    if (room[i] == r)
                        printf(" %s(%d-%d)", lectures[i].name,
                               lectures[i].start, lectures[i].finish);
                }
                printf("\n");
            }
        } else if (choice == 3) {
            printf("Goodbye!\n");
            break;
        } else {
            printf("Please choose 1, 2 or 3.\n");
        }
    }
    return 0;
}